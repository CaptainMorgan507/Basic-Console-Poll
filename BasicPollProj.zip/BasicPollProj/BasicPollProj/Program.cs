﻿using System;
using System.Data;
using System.IO;

namespace Helloworld
{
    class Polls
    {
        private short[] calif = new short[5];

        public void asignCalif(short data)
        {
            calif[data]++;
            Console.WriteLine("New calif for " + data + " is: " + calif[data]);
        }

        public short[] returnCalif()
        {
            for (int i = 1; i < calif.Length; i++)
            {
                calif[0] = (short)(calif[0] + calif[i]);
            }
            return calif;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // we create our object.
            Polls objPoll = new Polls();

            //here we store the data inserted by the user
            short data;
            //our control variable for handling exceptions or bad entries
            bool eval = false;
            //The results variable.
            short[] results = new short[5];

            //This controll bool variable will decide when the user wants to exit or continue.
            bool exit = false;

            //this variable will store the users commands
            char command;
            //start and welcome message
            Console.WriteLine("Program for poll");

            while (exit == false)
            {
                while (eval == false)
                {
                    Console.Clear();
                    try
                    {
                        eval = true;
                        Console.WriteLine("Please rate our food, the rating is:" +
                                        "\n  -1: Terrible" +
                                        "\n  -2: Bad" +
                                        "\n  -3: Good" +
                                        "\n  -4: Excelent" +
                                        "\n  Your choice is:");
                        data = Convert.ToInt16(Console.ReadLine());

                        if ((data > 0) && (data < 5))
                        {
                            objPoll.asignCalif(data);
                        }
                        else
                        {
                            eval = false;
                        }


                    }
                    catch (IOException e)
                    {
                        eval = false;
                        if (e.Source != null)
                            Console.WriteLine("IOException source: {0}", e.Source);
                    }

                }
                eval = false;

                while (eval == false)
                {
                    Console.Clear();
                    try
                    {
                        eval = true;
                        Console.WriteLine("\nWould you like to do a new rating?" +
                                        "\n  -c: Continue with new rating" +
                                        "\n  -e: for exit and view all the ratings" +
                                        "\n  Your choice is:");
                        command = Console.ReadLine()[0];

                        Console.Write("Letter read is: " + command);

                        if (command == 'c')
                        {
                            exit = false;
                        }
                        else if (command == 'e')
                        {
                            exit = true;
                            Console.Write("\nexiting");
                        }
                        else
                        {
                            exit = false;
                            eval = false;
                        }

                    }
                    catch (IOException e)
                    {
                        eval = false;
                        if (e.Source != null)
                            Console.WriteLine("IOException source: {0}", e.Source);
                    }


                }
                eval = false;
            }
            Console.Clear();
            results = objPoll.returnCalif();

            Console.WriteLine("The total of votes where: " + results[0]);

            for (int i = 1; i < 5; i++)
            {
                Console.WriteLine("The result for poll: " + i + " is: " + results[i]);
            }
            Console.WriteLine("End of the program");

        }
    }
}
